import React, { useState } from "react";
import { MdOutlineLocalOffer } from "react-icons/md";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { CiMoneyBill } from "react-icons/ci";
import { GrWorkshop } from "react-icons/gr";
import { backend_url } from "../../server";
import { FiBell, FiSearch, FiHelpCircle, FiMenu, FiX } from "react-icons/fi";
import logo from '../../Assests/logo.png';
import { AiOutlineShopping, AiOutlineDollar, AiOutlineCalendar, AiOutlineEye, AiOutlineNumber } from "react-icons/ai";
import { Button } from "@material-ui/core";
import { RxDashboard } from "react-icons/rx";
import { FiShoppingBag, FiUsers, FiSettings } from "react-icons/fi";
import { BsHandbag } from "react-icons/bs";

const AdminHeader = () => {
  const { user } = useSelector((state) => state.user);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="w-full min-h-[80px] bg-white shadow-lg sticky top-0 left-0 z-30">
      <div className="max-w-[1920px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-[80px]">
          {/* Logo Section */}
          <div>
            <Link to="/" className="flex items-center gap-2 sm:gap-3">
              <img 
                src={logo}
                alt="App Logo"
                className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 object-contain"
              />
              <h1 className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent">
                Qauds
              </h1>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <div className="flex items-center gap-6">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search..."
                  className="w-[200px] pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
                <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              </div>
            </div>

            {/* Notifications and Help */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <FiBell size={22} className="text-gray-600 cursor-pointer hover:text-blue-600 transition-colors duration-300" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center animate-pulse">
                  3
                </span>
              </div>
              <FiHelpCircle size={22} className="text-gray-600 cursor-pointer hover:text-blue-600 transition-colors duration-300" />
            </div>

            {/* User Profile */}
            <div className="flex items-center gap-4 pl-4 lg:pl-6 border-l">
              <div className="text-right">
                <h3 className="text-sm font-medium text-gray-700">{user?.name}</h3>
                <p className="text-xs text-gray-500">Administrator</p>
              </div>
              <div className="relative group">
                <img
                  src={`${backend_url}${user?.avatar}`}
                  alt=""
                  className="w-[40px] h-[40px] rounded-full object-cover border-2 border-blue-500 cursor-pointer transform transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
              </div>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-4">
            <div className="relative">
              <FiBell size={22} className="text-gray-600 cursor-pointer hover:text-blue-600 transition-colors duration-300" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center animate-pulse">
                3
              </span>
            </div>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 rounded-lg hover:bg-gray-100"
            >
              {isMenuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <div className="px-4 py-3 space-y-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search..."
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            </div>
            
            <Link to="/admin/dashboard" className="block">
              <div className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors duration-300 p-2 rounded-lg hover:bg-gray-50">
                <RxDashboard size={20} />
                <span className="text-sm font-medium">Dashboard</span>
              </div>
            </Link>
            
            <Link to="/admin-orders" className="block">
              <div className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors duration-300 p-2 rounded-lg hover:bg-gray-50">
                <FiShoppingBag size={20} />
                <span className="text-sm font-medium">All Orders</span>
              </div>
            </Link>
            
            <Link to="/admin-sellers" className="block">
              <div className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors duration-300 p-2 rounded-lg hover:bg-gray-50">
                <GrWorkshop size={20} />
                <span className="text-sm font-medium">All Sellers</span>
              </div>
            </Link>

            <Link to="/admin-users" className="block">
              <div className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors duration-300 p-2 rounded-lg hover:bg-gray-50">
                <FiUsers size={20} />
                <span className="text-sm font-medium">All Users</span>
              </div>
            </Link>

            <Link to="/admin-products" className="block">
              <div className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors duration-300 p-2 rounded-lg hover:bg-gray-50">
                <BsHandbag size={20} />
                <span className="text-sm font-medium">All Products</span>
              </div>
            </Link>

            <Link to="/admin-events" className="block">
              <div className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors duration-300 p-2 rounded-lg hover:bg-gray-50">
                <MdOutlineLocalOffer size={20} />
                <span className="text-sm font-medium">All Events</span>
              </div>
            </Link>

            <Link to="/admin-withdraw-request" className="block">
              <div className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors duration-300 p-2 rounded-lg hover:bg-gray-50">
                <CiMoneyBill size={20} />
                <span className="text-sm font-medium">Withdraw Requests</span>
              </div>
            </Link>

            <Link to="/admin-settings" className="block">
              <div className="flex items-center gap-2 text-gray-600 hover:text-blue-600 transition-colors duration-300 p-2 rounded-lg hover:bg-gray-50">
                <FiSettings size={20} />
                <span className="text-sm font-medium">Settings</span>
              </div>
            </Link>

            <div className="flex items-center gap-2 text-gray-600 p-2 rounded-lg">
              <FiHelpCircle size={20} />
              <span className="text-sm font-medium">Help</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminHeader;
